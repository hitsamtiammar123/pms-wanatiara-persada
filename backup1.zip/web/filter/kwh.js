app.filter('kwh',function(){
    return function(){
        return '根据需要 Sesuai  kebutuhan';
    }
});
