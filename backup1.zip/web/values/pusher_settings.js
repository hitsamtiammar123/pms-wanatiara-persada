app.constant('pusher_settings',{
    pusher_id:'503b00ee47cd8506c7c9',
    cluster:'ap1',
    forceTLS: true,
    authEndpoint:'broadcasting/auth'
}); 