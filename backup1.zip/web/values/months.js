app.value('months',[
    {
        value:"January 一月",
        index:0
    },
    {
        value:"February 二月",
        index:1
    },
    {
        value:"March 三月",
        index:2
    },
    {
        value:"April 四月",
        index:3
    },
    {
        value:"May 五月",
        index:4
    },
    {
        value:"June 六月",
        index:5
    },
    {
        value:"July 七月",
        index:6
    },
    {
        value:"August 八月",
        index:7
    },
    {
        value:"September 九月",
        index:8
    },
    {
        value:"October 十月",
        index:9
    },
    {
        value:"November 十一月",
        index:10
    },
    {
        value:"December 十二月",
        index:11
    }
]);
