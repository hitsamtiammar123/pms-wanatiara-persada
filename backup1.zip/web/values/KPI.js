app.constant('KPI_RESULT','kpiresult');
app.constant('KPI_PROCESS','kpiprocess');
