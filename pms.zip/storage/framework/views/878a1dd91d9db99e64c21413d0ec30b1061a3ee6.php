<!DOCTYPE html>
<html lang="en">
<head>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php echo $__env->make('include.head-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link rel="stylesheet" href="css/style.css">
<script src="javascript/app"></script>
</head>
<body>
  <div id="app"></div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\pms-wanatiara-persada-v1-laravel\resources\views/app.blade.php ENDPATH**/ ?>