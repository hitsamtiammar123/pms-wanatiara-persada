<?php $__env->startSection('content'); ?>

<section class="row">
    <p class="p1">Sistem Manajemen Kinerja
        </p>
    <p class="p2">Performance Management System (PMS)
        </p>
</section>

<footer id="footer" class="row">
    <div class="col-sm-6">
            <p class="f1">
                    Setiap diri akan mendapat balasan dan derajat sesuai dengan apa yang dilakukannya.
            </p>
            <p class="f2">
                    每个自己都会根据自己的所作所为获得答复和学位
            </p>
    </div>
    <div class="col-sm 2">
        <p class="login-t">
                <a href="login" class="login-href">Masuk 登录
                    </a>
        </p>
    </div>

</footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pms',['head'=>'include.head-landing'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pms-wanatiara-persada-v1-laravel\resources\views/index.blade.php ENDPATH**/ ?>