<!DOCTYPE html>
<html lang="en">
<head>>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <link rel="stylesheet" href="<?php echo e(res_url('vendor/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(public_path('css-laravel/pdf.css')); ?>">
    <title><?php echo e(isset($title)?$title:'PDF PMS'); ?></title>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\pms-wanatiara-persada-v1-laravel\resources\views/layouts/pdf.blade.php ENDPATH**/ ?>