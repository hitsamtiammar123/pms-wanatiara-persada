<?php $__env->startSection('content'); ?>
<?php
    function get_totalW_pw1($carry,$item){
        return $carry+intval($item['pw_1']);
    }

    function get_totalW_pw2($carry,$item){
        return $carry+intval($item['pw_2']);
    }

    $cPeriod=$header->cPeriod();
    $cPrevPeriod=$header->cPrevPeriod();
    $cNextPeriod=$header->cNextPeriod();
    $cCumPeriod=$header->cCumStartPeriod();
    $finalAcievement=$header->getFinalAchivement($kpiresults,$kpiprocesses);
?>
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
            <div class="navbar-header">
                    <a class="navbar-brand" href="#">Tekan Ctrl+P untuk mencetak halaman</a>
                  </div>
    </div>
</nav>
<div class="c-container">
        <div class="row">
                <div class="col-sm-2">
                    <img src="<?php echo e(asset('img/logo-removebg.png')); ?>" alt="" class="logo">
                    </div>
                    <div class="col-sm-7">
                        <div class="row">
                            <h3 class="title1">Sistem Manajemen Kinerja (PMS) 绩效考核管理体系 </h3>
                            <h4 class="title2">PT Wanatiara Persada <?php echo e($cPeriod->format('Y')); ?> </h4>
                        </div>
                    </div>
        </div>
        <div class="row title-row">
                <div class="col-sm-3"><?php echo e($employee->role->name); ?>: </div>
                <div class="col-sm-2"> <?php echo e($employee->name); ?></div>
                <div class="col-sm-4">当月考核期 Periode bulan berjalan:</div>
                <div class="col-sm-3"> <?php echo e($cPrevPeriod->format('d M Y')); ?> - <?php echo e($cPeriod->format('d M Y')); ?></div>
        </div>
        <div class="row" style="margin-top:10px;">
                <div class="col-sm-3"><?php echo e($employee->atasan->role->name); ?>:</div>
                <div class="col-sm-2"> <?php echo e($employee->atasan->name); ?></div>
                <div class="col-sm-4">当月考核期 Periode bulan berjalan:</div>
                <div class="col-sm-3"> <?php echo e($cCumPeriod->format('d M Y')); ?> - <?php echo e($cPeriod->format('d M Y')); ?></div>
        </div>

            <div class="title-row">
                <p class="pms-title">1. Sasaran Hasil: <?php echo e($header->weight_result*100); ?>%</p>
            </div>
            <div class="table-content page-break">
                    <div class="col-sm-12 ">
                            <table class="table table-print ">
                                    <thead>
                                        <tr>
                                            <th rowspan="2">KPI</th>
                                            <th rowspan="2">Unit</th>
                                            <th colspan="2">Performance Wighing 2019</th>
                                            <th colspan="4">Performance Target 2019</th>
                                            <th colspan="4">Realization 2019</th>
                                            <th colspan="2">KPI Achievement 2019</th>
                                            <th colspan="2">Achievement x Weighing</th>
                                        </tr>
                                        <tr>
                                            <?php $__currentLoopData = $header->getResultHeading(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <th><?php echo e($h); ?></th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>

                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $kpiresults['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpiresult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                    <td class="kpi-content"><?php echo e($kpiresult['name']); ?></td>
                                                    <td><?php echo e($kpiresult['unit']); ?></td>
                                                    <td class="num-content"><?php echo e($kpiresult['pw_1']); ?></td>
                                                    <td class="num-content"><?php echo e($kpiresult['pw_2']); ?></td>
                                                    <td class="num-content"><?php echo e($kpiresult['pt_t1']); ?></td>
                                                    <td class="num-content"><?php echo e($kpiresult['pt_k1']); ?></td>
                                                    <td class="num-content"><?php echo e($kpiresult['pt_t2']); ?></td>
                                                    <td class="num-content"><?php echo e($kpiresult['pt_k2']); ?></td>
                                                    <td class="num-content"><?php echo e($kpiresult['real_t1']); ?></td>
                                                    <td class="num-content"><?php echo e($kpiresult['real_k1']); ?></td>
                                                    <td class="num-content"><?php echo e($kpiresult['real_t2']); ?></td>
                                                    <td class="num-content"><?php echo e($kpiresult['real_k2']); ?></td>
                                                    <td class="num-content <?php echo e($kpiresult['bColor_kpia_1']); ?>"><?php echo e($kpiresult['kpia_1']); ?></td>
                                                    <td class="num-content <?php echo e($kpiresult['bColor_kpia_2']); ?>"><?php echo e($kpiresult['kpia_2']); ?></td>
                                                    <td class="num-content"><?php echo e($kpiresult['aw_1']); ?></td>
                                                    <td class="num-content"><?php echo e($kpiresult['aw_2']); ?></td>
                                                </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td colspan="2" class="bold">Total Bobot: </td>
                                                <td class="num-content"><?php echo e(array_reduce($kpiresults['data'],'get_totalW_pw1',0)); ?>%</td>
                                                <td class="num-content"><?php echo e(array_reduce($kpiresults['data'],'get_totalW_pw2',0)); ?>%</td>
                                                <td colspan="8"></td>
                                                <td colspan="2" class="bold">Total Achievement:</td>
                                                <td class="num-content center-text"><?php echo e($kpiresults['totalAchievement']['t1']); ?></td>
                                                <td class="num-content center-text"><?php echo e($kpiresults['totalAchievement']['t2']); ?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="12"></td>
                                                <td colspan="2" class="bold">Index Achievement:</td>
                                                <td class="num-content center-text"><?php echo e($kpiresults['indexAchievement']['t1']); ?></td>
                                                <td class="num-content center-text"><?php echo e($kpiresults['indexAchievement']['t2']); ?></td>
                                            </tr>
                                    </tbody>
                            </table>
                    </div>
            </div>
            <div class="page-break">
                <div class="title-row">
                    <p class="pms-title">2. Sasaran Proses: <?php echo e($header->weight_process*100); ?>%</p>
                </div>
                <div class="table-content ">
                                <div class="col-sm-12">
                                        <table class="table table-print">
                                                <thead>
                                                    <tr>
                                                        <th rowspan="2">Kompetensi Inti</th>
                                                        <th rowspan="2">Unit</th>
                                                        <th colspan="2">Performance weighting <?php echo e($cPeriod->format('Y')); ?></th>
                                                        <th colspan="2">Performance Target <?php echo e($cPeriod->format('Y')); ?></th>
                                                        <th colspan="2">Realization <?php echo e($cPeriod->format('Y')); ?></th>
                                                        <th colspan="2">KPI Achievement <?php echo e($cPeriod->format('Y')); ?></th>
                                                        <th colspan="2">Achievement x Weighing</th>
                                                    </tr>
                                                    <tr>
                                                        <?php $__currentLoopData = $header->getProcessHeading(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <th><?php echo e($h); ?></th>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tr>

                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $kpiprocesses['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpiprocess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                                <td><?php echo e($kpiprocess['name']); ?></td>
                                                                <td><?php echo e($kpiprocess['unit']); ?></td>
                                                                <td class="num-content"><?php echo e($kpiprocess['pw_1']); ?></td>
                                                                <td class="num-content"><?php echo e($kpiprocess['pw_1']); ?></td>
                                                                <td class="num-content"><?php echo e($kpiprocess['pt_1']); ?></td>
                                                                <td class="num-content"><?php echo e($kpiprocess['pt_2']); ?></td>
                                                                <td class="num-content"><?php echo e($kpiprocess['real_1']); ?></td>
                                                                <td class="num-content"><?php echo e($kpiprocess['real_2']); ?></td>
                                                                <td class="num-content <?php echo e($kpiresult['bColor_kpia_1']); ?>"><?php echo e($kpiprocess['kpia_1']); ?></td>
                                                                <td class="num-content <?php echo e($kpiresult['bColor_kpia_2']); ?>"><?php echo e($kpiprocess['kpia_2']); ?></td>
                                                                <td class="num-content"><?php echo e($kpiprocess['aw_1']); ?></td>
                                                                <td class="num-content"><?php echo e($kpiprocess['aw_2']); ?></td>
                                                            </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td colspan="2" class="bold">Total Bobot: </td>
                                                            <td class="num-content"><?php echo e(array_reduce($kpiprocesses['data'],'get_totalW_pw1',0)); ?>%</td>
                                                            <td class="num-content"><?php echo e(array_reduce($kpiprocesses['data'],'get_totalW_pw2',0)); ?>%</td>
                                                            <td colspan="4"></td>
                                                            <td colspan="2" class="bold">Total Achievement:</td>
                                                            <td class="num-content center-text"><?php echo e($kpiprocesses['totalAchievement']['t1']); ?></td>
                                                            <td class="num-content center-text"><?php echo e($kpiprocesses['totalAchievement']['t2']); ?></td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="8"></td>
                                                            <td colspan="2" class="bold">Index Achievement:</td>
                                                            <td class="num-content center-text"><?php echo e($kpiprocesses['indexAchievement']['t1']); ?></td>
                                                            <td class="num-content center-text"><?php echo e($kpiprocesses['indexAchievement']['t2']); ?></td>
                                                        </tr>
                                                </tbody>
                                            </table>
                                </div>

                </div>
            </div>
            <div class="table-content">
                    <div class="col-sm-4">
                        <table class="table table-print">
                                <thead>
                                        <tr>
                                            <th rowspan="2">价值总额 TOTAL NILAI</th>
                                            <th><?php echo e($finalAcievement['t1_n']); ?>%</th>
                                            <th><?php echo e($finalAcievement['t2_n']); ?>%</th>
                                        </tr>
                                        <tr>
                                            <th><?php echo e($finalAcievement['t1_i']); ?></th>
                                            <th><?php echo e($finalAcievement['t2_i']); ?></th>
                                        </tr>
                                        <tr>
                                            <th>指数 Indeks</th>
                                            <th><?php echo e($finalAcievement['t1_f']); ?>%</th>
                                            <th><?php echo e($finalAcievement['t2_f']); ?>%</th>
                                        </tr>
                                    </thead>
                        </table>
                    </div>
                    <div class="col-sm-8"></div>
            </div>



    <div class="col-sm-12">
        <p>PMS ini sudah disahkan secara elektronik 该绩效考核管理体系已经过电子批准.</p>
    </div>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.print', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pms-wanatiara-persada-v1-laravel\resources\views/print/pms.blade.php ENDPATH**/ ?>