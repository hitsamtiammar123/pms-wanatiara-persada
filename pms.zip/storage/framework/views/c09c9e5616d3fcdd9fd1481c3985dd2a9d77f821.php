<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-3"></div>
        <div class="col-sm-6">
            <form action="<?php echo e(route('password.email')); ?>" method="POST" class="form-horizontal">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="id">Silakan masukan email yang terdaftar	: </label>
                        <input class="form-control" id="email" type="text" name="email" required autocomplete="email" autofocus>
                    </div>
                    <style>
                        .error-p{
                            color:red;
                        }
                        .success-p{
                            margin-top:15px;
                        }
                    </style>

                    <div class="form-group">
                        <button type="submit" class="btn btn-default">Kirim</button>
                        <?php if($errors->any()): ?>

                            <p>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="error-p"><?php echo e($error); ?></div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </p>
                        <?php endif; ?>
                        <?php if(session('status')): ?>
                        <div class="alert alert-success success-p" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                        <?php endif; ?>
                    </div>
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.pms',['head'=>'include.head-landing'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pms-wanatiara-persada-v1-laravel\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>