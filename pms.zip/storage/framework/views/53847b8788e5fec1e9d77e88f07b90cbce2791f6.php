<p>Halo</p>
<p>
    Berikut kami kirimkan tautan untuk mereset password anda.
</p>
<p>
klik <a href="<?php echo e(route('password.reset',['token'=>$token]).'?email='.$email); ?>">tautan</a> berikut ini.
</p>
<p>
    Tautan reset password ini akan kadaluarsa dalam 60 menit.
</p>
<?php /**PATH C:\xampp\htdocs\pms\resources\views/mail/reset-password.blade.php ENDPATH**/ ?>