<?php
    $js_vendors=[res_url('vendor/js/jquery.min.js'),res_url('vendor/js/bootstrap.min.js')];
    $css_vendors=[ res_url('vendor/css/bootstrap.min.css'),res_url("vendor/css/bootstrap-theme.min.css")];
?>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<?php $__currentLoopData = $css_vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $css): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<link rel="stylesheet" href="<?php echo e($css); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<link rel="icon" href="<?php echo e(url('img/logo-removebg.png')); ?>">
<?php $__currentLoopData = $js_vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<script src="<?php echo e($vendor); ?>"></script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<title>PT Wanatiara Persada</title>
<?php /**PATH C:\xampp\htdocs\pms-wanatiara-persada-v1-laravel\resources\views/include/head-landing.blade.php ENDPATH**/ ?>