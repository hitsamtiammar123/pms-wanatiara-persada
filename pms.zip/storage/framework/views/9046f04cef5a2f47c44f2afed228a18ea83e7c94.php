<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make($head, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(url('css-laravel/index.css')); ?>">
</head>
<body>
    <div class="container">
        <header class="row">
                <div class="page-header">
                        <div class="col-sm-1">
                            <a href="<?php echo e(route('index')); ?>">
                                <img src="<?php echo e(url('img/logo-removebg.png')); ?>" class="head-img">
                        </a></div>
                        <div><h1 class="head-title bold"> PT Wanatiara Persada</h1></div>
                    </div>
        </header>

        <?php echo $__env->yieldContent('content'); ?>

    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\pms-wanatiara-persada-v1-laravel\resources\views/layouts/pms.blade.php ENDPATH**/ ?>