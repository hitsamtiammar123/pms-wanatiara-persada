<?php $__env->startSection('content'); ?>
<?php
    function get_totalW_pw1($carry,$item){
        return $carry+intval($item['pw_1']);
    }

    function get_totalW_pw2($carry,$item){
        return $carry+intval($item['pw_2']);
    }

    $cPeriod=$header->cPeriod();
    $cNextPeriod=$header->cNextPeriod();
    $cPrevPeriod=$header->cPrevPeriod();
    $cCumPeriod=$header->cCumStartPeriod();
    $finalAcievement=$header->getFinalAchivement($kpiresults,$kpiprocesses);
?>
    <style>
        body{
            font-family:'msyh';
        }
    </style>

    <div class="c container">
        <div class="row">
            <div class="col-xs-2">
                <img src="<?php echo e(public_path('img/logo-removebg.png')); ?>" class="head-image">
            </div>
            <div class="col-xs-8">
                <p class="head-title"> PT Wanatiara Persada</p>
            </div>
        </div>

        <div class="row margin-heading">
                <div class="col-xs-2"><?php echo e($employee->role->name); ?></div>
                <div class="col-xs-2">: <?php echo e($employee->name); ?></div>
                <div class="col-xs-3">年责任权重 Periode bulan berjalan</div>
                <div class="col-xs-3">: <?php echo e($cPrevPeriod->format('d M Y')); ?> - <?php echo e($cPeriod->format('d M Y')); ?></div>
        </div>
        <div class="row" style="margin-top:10px;">
                <div class="col-xs-2"><?php echo e($employee->atasan->role->name); ?></div>
                <div class="col-xs-2">: <?php echo e($employee->atasan->name); ?></div>
                <div class="col-xs-3">年绩效目标 Periode Kumulatif sampai bulan berjalan</div>
                <div class="col-xs-3">: <?php echo e($cCumPeriod->format('d M Y')); ?> - <?php echo e($cPeriod->format('d M Y')); ?></div>
        </div>
        <div class="row title-row">
            <p class="pms-title">1. Sasaran Hasil: <?php echo e($header->weight_result*100); ?>%</p>
        </div>
        <div class="row table-content">
            <table class="table table-bordered table-pdf">
                <thead>
                    <tr>
                        <th rowspan="2">No</th>
                        <th rowspan="2">Key Performance Indicator</th>
                        <th rowspan="2">Unit</th>
                        <th colspan="2">Performance Wighing <?php echo e($cPeriod->format('Y')); ?></th>
                        <th colspan="4">Performance Target <?php echo e($cPeriod->format('Y')); ?></th>
                        <th colspan="4">Realization <?php echo e($cPeriod->format('Y')); ?></th>
                        <th colspan="2">KPI Achievement <?php echo e($cPeriod->format('Y')); ?></th>
                        <th colspan="2">Achievement x Weighing</th>
                    </tr>
                    <tr>
                        <?php $__currentLoopData = $header->getResultHeading(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($h); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>

                </thead>
                <tbody>
                    <?php $__currentLoopData = $kpiresults['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpiresult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                                <td class="index-content"><?php echo e($loop->index+1); ?></td>
                                <td class="kpi-content"><?php echo e($kpiresult['name']); ?></td>
                                <td class="index-content"><?php echo e($kpiresult['unit']); ?></td>
                                <td class="num-content"><?php echo e(@$kpiresult['pw_1']); ?></td>
                                <td class="num-content"><?php echo e($kpiresult['pw_2']); ?></td>
                                <td class="num-content"><?php echo e(@$kpiresult['pt_t1']); ?></td>
                                <td class="num-content"><?php echo e(@$kpiresult['pt_k1']); ?></td>
                                <td class="num-content"><?php echo e($kpiresult['pt_t2']); ?></td>
                                <td class="num-content"><?php echo e($kpiresult['pt_k2']); ?></td>
                                <td class="num-content"><?php echo e(@$kpiresult['real_t1']); ?></td>
                                <td class="num-content"><?php echo e(@$kpiresult['real_k1']); ?></td>
                                <td class="num-content"><?php echo e($kpiresult['real_t2']); ?></td>
                                <td class="num-content"><?php echo e($kpiresult['real_k2']); ?></td>
                                <td class="num-content <?php echo e($kpiresult['bColor_kpia_1']); ?>"><?php echo e(@$kpiresult['kpia_1']); ?></td>
                                <td class="num-content <?php echo e($kpiresult['bColor_kpia_2']); ?>"><?php echo e($kpiresult['kpia_2']); ?></td>
                                <td class="num-content"><?php echo e(@$kpiresult['aw_1']); ?></td>
                                <td class="num-content"><?php echo e($kpiresult['aw_2']); ?></td>
                            </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="3" class="footer-title-tbl">Total Bobot: </td>
                            <td class="num-content"><?php echo e(array_reduce($kpiresults['data'],'get_totalW_pw1',0)); ?>%</td>
                            <td class="num-content"><?php echo e(array_reduce($kpiresults['data'],'get_totalW_pw2',0)); ?>%</td>
                            <td colspan="8"></td>
                            <td colspan="2" class="footer-title-tbl">Total Achievement:</td>
                            <td class="num-content"><?php echo e($kpiresults['totalAchievement']['t1']); ?></td>
                            <td class="num-content"><?php echo e($kpiresults['totalAchievement']['t2']); ?></td>
                        </tr>
                        <tr>
                            <td colspan="13"></td>
                            <td colspan="2" class="footer-title-tbl">Index Achievement:</td>
                            <td class="num-content"><?php echo e($kpiresults['indexAchievement']['t1']); ?></td>
                            <td class="num-content"><?php echo e($kpiresults['indexAchievement']['t2']); ?></td>
                        </tr>
                </tbody>
            </table>
        </div>
        <div class="row">
                <p class="pms-title">2. Sasaran Proses: <?php echo e($header->weight_process*100); ?>%</p>
            </div>
        <div class="row table-content">
                <table class="table table-bordered table-pdf">
                    <thead>
                        <tr>
                            <th rowspan="2">序号 No.</th>
                            <th rowspan="2">核心竞争力 Kompetensi Inti</th>
                            <th rowspan="2">单位 Unit</th>
                            <th colspan="2">Performance Wighing <?php echo e($cPeriod->format('Y')); ?></th>
                            <th colspan="2">Performance Target <?php echo e($cPeriod->format('Y')); ?></th>
                            <th colspan="2">Realization <?php echo e($cPeriod->format('Y')); ?></th>
                            <th colspan="2">KPI Achievement <?php echo e($cPeriod->format('Y')); ?></th>
                            <th colspan="2">Achievement x Weighing</th>
                        </tr>
                        <tr>
                            <?php $__currentLoopData = $header->getProcessHeading(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($h); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>

                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $kpiprocesses['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpiprocess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                    <td class="index-content"><?php echo e($loop->index+1); ?></td>
                                    <td class="kpi-content"><?php echo e($kpiprocess['name']); ?></td>
                                    <td class="text-center"><?php echo e($kpiprocess['unit']); ?></td>
                                    <td class="num-content"><?php echo e(@$kpiprocess['pw_1']); ?></td>
                                    <td class="num-content"><?php echo e($kpiprocess['pw_2']); ?></td>
                                    <td class="num-content"><?php echo e(@$kpiprocess['pt_1']); ?></td>
                                    <td class="num-content"><?php echo e($kpiprocess['pt_2']); ?></td>
                                    <td class="num-content"><?php echo e(@$kpiprocess['real_1']); ?></td>
                                    <td class="num-content"><?php echo e($kpiprocess['real_2']); ?></td>
                                    <td class="num-content <?php echo e($kpiprocess['bColor_kpia_1']); ?>"><?php echo e($kpiprocess['kpia_1']); ?></td>
                                    <td class="num-content <?php echo e($kpiprocess['bColor_kpia_2']); ?>"><?php echo e($kpiprocess['kpia_2']); ?></td>
                                    <td class="num-content"><?php echo e(@$kpiprocess['aw_1']); ?></td>
                                    <td class="num-content"><?php echo e($kpiprocess['aw_2']); ?></td>
                                </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                                <td colspan="3" class="footer-title-tbl">Total Bobot: </td>
                                <td class="num-content"><?php echo e(array_reduce($kpiprocesses['data'],'get_totalW_pw1',0)); ?>%</td>
                                <td class="num-content"><?php echo e(array_reduce($kpiprocesses['data'],'get_totalW_pw2',0)); ?>%</td>
                                <td colspan="4"></td>
                                <td colspan="2" class="footer-title-tbl">Total Achievement:</td>
                                <td class="num-content"><?php echo e($kpiprocesses['totalAchievement']['t1']); ?></td>
                                <td class="num-content"><?php echo e($kpiprocesses['totalAchievement']['t2']); ?></td>
                            </tr>
                            <tr>
                                <td colspan="9"></td>
                                <td colspan="2" class="footer-title-tbl">Index Achievement:</td>
                                <td class="num-content"><?php echo e($kpiprocesses['indexAchievement']['t1']); ?></td>
                                <td class="num-content"><?php echo e($kpiprocesses['indexAchievement']['t2']); ?></td>
                            </tr>
                    </tbody>
                </table>
        </div>
        <div class="row table-content">
            <div class="col-xs-4">
                    <table class="table table-bordered table-pdf">
                            <thead>
                                <tr>
                                    <th class="light-grey"></th>
                                    <th class="light-grey"><?php echo e($cPrevPeriod->format('M')); ?></th>
                                    <th class="light-grey"><?php echo e($cPeriod->format('M')); ?></th>
                                </tr>
                                <tr>
                                    <th rowspan="2">价值总额 TOTAL NILAI</th>
                                    <th><?php echo e($finalAcievement['t1_n']); ?>%</th>
                                    <th><?php echo e($finalAcievement['t2_n']); ?>%</th>
                                </tr>
                                <tr>
                                    <th><?php echo e($finalAcievement['t1_i']); ?></th>
                                    <th><?php echo e($finalAcievement['t2_i']); ?></th>
                                </tr>
                                <tr>
                                    <th>指数 Indeks</th>
                                    <th><?php echo e($finalAcievement['t1_f']); ?>%</th>
                                    <th><?php echo e($finalAcievement['t2_f']); ?>%</th>
                                </tr>
                            </thead>
                        </table>
            </div>

        </div>
        <div class="row">
            <?php if($header->hasFullEndorse()): ?>
            <p class="pms-title endorsement-title green-column" style="font-style:italic !important">PMS ini sudah disahkan secara elektronik 该绩效考核管理体系已经过电子批准.</p>
            <?php else: ?>
            <p class="pms-title endorsement-title red-column" style="font-style:italic !important">PMS ini belum keseluruhan disahkan 该绩效考核管理体系尚未完全获得批准.</p>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pdf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pms-wanatiara-persada-v1-laravel\resources\views/pdf/pdf-pms.blade.php ENDPATH**/ ?>