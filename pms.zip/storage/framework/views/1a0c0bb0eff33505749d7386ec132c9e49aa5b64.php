<?php $__env->startSection('content'); ?>
<?php

    $cPeriod=$curr_header->cPeriod();
    $cNextPeriod=$curr_header->cNextPeriod();
    $cPrevPeriod=$curr_header->cPrevPeriod();
    $cCumPeriod=$curr_header->cCumStartPeriod();
    $m=$curr_header->month;
    $y=$curr_header->year;
    $kpiprocessgroup=$kpitag->groupkpiprocess;
    $kpiresultgroup=$kpitag->groupkpiresult;
?>
<style>
    body{
        font-family:'msyh';
    }
</style>
<div class="container">
    <div class="row">
        <div class="col-xs-2">
            <img src="<?php echo e(public_path('img/logo-removebg.png')); ?>" class="head-image">
        </div>
        <div class="col-xs-8">
            <p class="head-title"> PT Wanatiara Persada</p>
        </div>
    </div>
    <div class="row margin-heading">
        <div class="col-xs-1">Penilaian Group</div>
        <div class="col-xs-3">: <?php echo e($kpitag->name); ?></div>
        <div class="col-xs-3">年责任权重 Periode bulan berjalan</div>
        <div class="col-xs-3">: <?php echo e($cPrevPeriod->format('d M Y')); ?> - <?php echo e($cPeriod->format('d M Y')); ?></div>
    </div>
    <div class="row" style="margin-top:10px;">
            <div class="col-xs-1">Penilai</div>
            <div class="col-xs-3">: <?php echo e($kpitag->representative->name); ?></div>
            <div class="col-xs-3">年绩效目标 Periode Kumulatif sampai bulan berjalan</div>
            <div class="col-xs-3">: <?php echo e($cCumPeriod->format('d M Y')); ?> - <?php echo e($cPeriod->format('d M Y')); ?></div>
    </div>
    <div class="row" style="margin-top:10px;">
        <div class="col-xs-1">Atasan Penilai</div>
        <div class="col-xs-3">: <?php echo e($kpitag->representative->atasan->name); ?></div>
    </div>
    <div class="row table-content">
        <table class="table table-bordered table-pdf">
            <thead>
                <tr>
                    <th rowspan="3">No</th>
                    <th rowspan="3" >Nama</th>
                    <th rowspan="3" >Penugasan</th>
                    <th ><?php echo e($curr_header->weight_result*100); ?>%</th>
                    <th colspan="<?php echo e($kpiresultgroup->count()*3-1); ?>" >Sasaran Hasil</th>
                    <th ><?php echo e($curr_header->weight_process*100); ?>%</th>
                    <th colspan="<?php echo e($kpiprocessgroup->count()*3-1); ?>">Sasaran Proses</th>
                    <th colspan="2">Total</th>
                </tr>
                <tr>
                    <?php $__currentLoopData = $kpiresultgroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpiresult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th colspan="2"><?php echo e($kpiresult->name); ?></th>
                        <th rowspan="2">R/T(%)</th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $kpiprocessgroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpiprocess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th colspan="2"><?php echo e($kpiprocess->name); ?></th>
                        <th rowspan="2">R/T(%)</th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th rowspan="2">Nilai</th>
                    <th rowspan="2">Index</th>
                </tr>
                <tr>
                    <?php for($i = 0; $i < $kpiresultgroup->count()+$kpiprocessgroup->count(); $i++): ?>
                        <th>Target</th>
                        <th>Realisasi</th>
                    <?php endfor; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $kpitag->groupemployee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php
                        $e_header=$employee->getHeader($m,$y);
                        $kpiresults=$e_header->fetchAccumulatedData('kpiresult',$kpiresultgroup);
                        $kpiprocesses=$e_header->fetchAccumulatedData('kpiprocess',$kpiprocessgroup);
                        $finalAcievement=$e_header->getFinalAchivement($kpiresults,$kpiprocesses);
                    ?>
                        <td class="index-content"><?php echo e($loop->index+1); ?></td>
                        <td class="kpi-content"><?php echo e($employee->name); ?></td>
                        <td class="kpi-content"><?php echo e($employee->role->name); ?></td>
                        <?php $__currentLoopData = $kpiresults['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpiresult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td class="num-content"><?php echo e($kpiresult['pt_t2']); ?></td>
                        <td class="num-content"><?php echo e($kpiresult['real_t2']); ?></td>
                        <td class="num-content <?php echo e($kpiresult['bColor_kpia_2']); ?>"><?php echo e($kpiresult['kpia_2']); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $kpiprocesses['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kpiprocess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td class="num-content"><?php echo e($kpiprocess['pt_2']); ?></td>
                        <td class="num-content"><?php echo e($kpiprocess['real_2']); ?></td>
                        <td class="num-content <?php echo e($kpiprocess['bColor_kpia_2']); ?>"><?php echo e($kpiprocess['kpia_2']); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td class="num-content"><?php echo e($finalAcievement['t2_n']); ?>%</td>
                        <td class="num-content"><?php echo e($finalAcievement['t2_i']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

    </div>
    <div class="row">
            <?php if($curr_header->hasFullEndorse()): ?>
            <p class="pms-title endorsement-title green-column" style="font-style:italic !important">PMS ini sudah disahkan secara elektronik 该绩效考核管理体系已经过电子批准.</p>
            <?php else: ?>
            <p class="pms-title endorsement-title red-column" style="font-style:italic !important">PMS ini belum keseluruhan disahkan 该绩效考核管理体系尚未完全获得批准.</p>
            <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pdf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pms-wanatiara-persada-v1-laravel\resources\views/pdf/pdf-pms-group.blade.php ENDPATH**/ ?>