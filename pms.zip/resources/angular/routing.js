app.provider('routing',function(){
    this.routelist={routelist}

    this.$get=function(){
        return {}
    }
})
