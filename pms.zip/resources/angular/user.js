app.constant('user',{user});
