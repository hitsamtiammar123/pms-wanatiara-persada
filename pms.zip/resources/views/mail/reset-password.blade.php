<p>Halo</p>
<p>
    Berikut kami kirimkan tautan untuk mereset password anda.
</p>
<p>
klik <a href="{{route('password.reset',['token'=>$token]).'?email='.$email}}">tautan</a> berikut ini.
</p>
<p>
    Tautan reset password ini akan kadaluarsa dalam 60 menit.
</p>
