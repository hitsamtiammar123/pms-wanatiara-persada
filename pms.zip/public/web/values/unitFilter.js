app.constant('unitFilter',[
    '%',
    'MV',
    '$',
    'WMT',
    '#',
    'MT',
    'MW',
    '规模 Scale',
    '规模 Skala',
    'kwh',
    'MW',
    'WMT/bulan'
]);  