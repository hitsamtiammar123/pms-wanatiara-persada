app.value('dumb',[
    {
      "kpi": "0",
      "unit": "%",
      "pw": {
        "q1": "5",
        "q2": "6",
        "q3": "5",
        "q4": "5",
        "contentEditable": "true"
      },
      "pt": {
        "q1": "5",
        "q2": "5",
        "q3": "5",
        "q4": "5",
        "contentEditable": "true"
      },
      "real": {
        "q1": "20",
        "q2": "5",
        "q3": "5",
        "q4": "5",
        "contentEditable": "true"
      },
      "kpia": {
        "q1": "85",
        "q2": "85",
        "q3": "85",
        "contentEditable": "false",
        "bColor1": "red-column",
        "bColor2": "red-column",
        "bColor3": "red-column",
        "q4": "85",
        "bColor4": "red-column"
      },
      "aw": {
        "q1": "4.25",
        "q2": "5.1",
        "q3": "4.25",
        "contentEditable": "false",
        "q4": "4.25"
      },
      "$$hashKey": "object:153"
    }
  ]) 