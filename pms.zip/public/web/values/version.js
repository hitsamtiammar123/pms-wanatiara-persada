app.constant('VERSION','1.0.0 (alpha)');
