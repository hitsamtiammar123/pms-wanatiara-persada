app.constant('commisioner',
{
        "nama_jabatan": "监事 Commisioner",
        "child": [],
        "bisa_punya_anak": false,
        "index": -1,
        "$$hashKey": "object:5",
        "parent": -1,
        "users":[0]
}) 